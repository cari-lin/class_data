Exported at 2026-03-23T18:49:18Z

Query: q=raccoon&quality_grade=any&identifications=any&iconic_taxa%5B%5D=Mammalia&place_id=1930&verifiable=true&spam=false

Columns:
id: Unique, sequential identifier for the observation
uuid: Universally unique identifier for the observation. See https://datatracker.ietf.org/doc/html/rfc9562
observed_on_string: Date/time as entered by the observer
observed_on: Normalized date of observation
time_observed_at: Normalized datetime of observation
time_zone: Time zone of observation
user_name: Name of the observer, generally used for attribution on the site. This is an optional field and may be a pseudonym
created_at: Datetime observation was created
updated_at: Datetime observation was last updated
latitude: Publicly visible latitude from the observation location
longitude: Publicly visible longitude from the observation location
private_latitude: Private latitude, set if observation private or obscured
private_longitude: Private longitude, set if observation private or obscured
coordinates_obscured: Whether or not the coordinates have been obscured, either because of geoprivacy or because of a threatened taxon
scientific_name: Scientific name of the observed taxon according to iNaturalist
common_name: Common or vernacular name of the observed taxon according to iNaturalist

For more information about column headers, see https://www.inaturalist.org/terminology

